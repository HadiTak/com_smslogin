<?php
defined('_JEXEC') or die;

return [
    'sms_api_key' => 'OWYxMWE1OTQtYjY0ZC00ZjVjLTlhMjgtMzkzZmM3MzQyOTYzNGE0ZDM4MDNiZTM4YjQ4OGY1YWI4ZjBjYmQ4MmUzZDM=',
    'sms_pattern_code' => 'ccuft7jdzc2ynw6',
    'sms_originator' => '+983000505',
    'sms_variable' => 'code',
    'sms_interval' => 10, // ثانیه
    'max_attempts' => 3,
    'lock_duration' => 600, // 10 دقیقه
    'log_path' => '/administrator/smslog.txt',
    'site_domain' => 'biral.ir'
];